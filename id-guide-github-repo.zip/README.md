# ID & Immunology Clinical Guide

A free clinical reference website for physicians, family doctors and allied health professionals
(infectious diseases, immunology, dosing, diet, pregnancy, daily quiz) plus a multilingual
patient-awareness section for the public. One static page: `index.html`.

## Publish with GitHub Pages (free)
1. Create a free account at github.com and click **New repository**. Name it (for example `id-guide`), make it **Public**.
2. Upload every file in this folder, keeping the folder names (`scripts/`, `.github/workflows/`).
   If the web uploader skips the hidden `.github` folder, click **Add file > Create new file**,
   type `.github/workflows/update-news.yml` as the name and paste the file contents.
3. **Settings > Pages**: Source = *Deploy from a branch*, Branch = `main`, folder = `/ (root)`. Save.
   Your site appears at `https://YOUR-USERNAME.github.io/id-guide/` within a few minutes.
4. **Settings > Actions > General > Workflow permissions**: choose **Read and write permissions**. Save.
5. Open the **Actions** tab, choose *Refresh outbreak news*, click **Run workflow** once to test.
   A green tick means the WHO headlines were fetched. From then on it runs every day at 03:00 UTC.

## How updates work
- **News (automatic):** `scripts/update_news.py` pulls the newest WHO Disease Outbreak News headlines
  into `news.json` each day and the site shows them. Only headline, date and link are stored.
  Items from other sources that you add by hand to `news.json` are kept (limit 12 items in total);
  delete old manual items now and then. The WHO endpoint could not be tested offline, so confirm the first run
  succeeded; if it fails the site simply keeps the last good `news.json`.
- **Everything else (manual):** open `index.html` on GitHub, click the pencil icon, edit, then **Commit changes**.
  The site updates in about a minute.
  - Quiz questions: the `QB` list near the end of the file (add questions in the same format).
  - Daily pearls: the `PL` list.
  - Dose, diet, pregnancy and awareness text: search the file for the heading you want to change.
- GitHub may pause scheduled runs after about 60 days with no repository activity; if that happens,
  re-enable the workflow in the Actions tab.

## Before sharing with colleagues
Have a physician, pharmacist and dietitian review doses and advice against your national guidelines,
and have native speakers check the Urdu, Hindi, Arabic and Bengali text. The site stores no patient data;
keep telling users not to enter names or ID numbers.
