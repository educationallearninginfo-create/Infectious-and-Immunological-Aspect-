#!/usr/bin/env python3
"""Refresh news.json with the latest WHO Disease Outbreak News headlines.

- Only the headline, date and link are stored (no article text is copied).
- Items from other sources that you add by hand to news.json are kept.
- If WHO cannot be reached, the existing news.json is left untouched.
"""
import json
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "news.json"
API = ("https://www.who.int/api/news/diseaseoutbreaknews?sf_culture=en"
       "&$orderby=PublicationDateAndTime%20desc&$top=8"
       "&$select=Title,PublicationDateAndTime,UrlName,ItemDefaultUrl")
BASE = "https://www.who.int/emergencies/disease-outbreak-news/item/"
MAX_ITEMS = 12


def fetch():
    req = urllib.request.Request(
        API, headers={"User-Agent": "id-guide-news-bot/1.0", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)


def load_old():
    try:
        return json.loads(OUT.read_text(encoding="utf-8")).get("items", [])
    except Exception:
        return []


def fmt(date):
    try:
        d = datetime.fromisoformat(date[:10])
        return f"{d.day} {d.strftime('%b %Y')}"
    except Exception:
        return date


def main():
    try:
        rows = fetch().get("value") or []
    except Exception as e:  # network or format problem: keep the old file
        print("WHO fetch failed, keeping existing news.json:", e)
        return 0
    old = load_old()
    notes = {i.get("u"): i.get("t", "") for i in old}
    who = []
    for r in rows:
        slug = r.get("UrlName") or (r.get("ItemDefaultUrl") or "").strip("/").split("/")[-1]
        title = (r.get("Title") or "").strip()
        if not slug or not title:
            continue
        url = BASE + slug
        who.append({"h": title, "t": notes.get(url, ""),
                    "d": fmt(r.get("PublicationDateAndTime") or ""), "s": "WHO", "u": url})
    if not who:
        print("No usable rows returned, keeping existing news.json")
        return 0
    manual = [i for i in old if i.get("s") != "WHO"]
    items = (who + manual)[:MAX_ITEMS]
    if items == old:
        print("No change")
        return 0
    stamp = datetime.now(timezone.utc).strftime("%d %b %Y %H:%M UTC")
    OUT.write_text(json.dumps({"updated": stamp, "items": items},
                              ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Updated with {len(items)} items")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
